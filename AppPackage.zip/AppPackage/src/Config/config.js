import md5 from 'md5';
const config = {
    api: "http://122.166.153.73:8888/api/api.php",
    //    http://122.166.153.73:8888/api/api.php

    //"http://ec2-3-14-75-203.us-east-2.compute.amazonaws.com/api/api.php
    apiKey:('a46435ecfff41505d1a156462e1aa24b'),
    version: 1,
    googleApiKey: 'AIzaSyBeaaajT33mBvWkTPRFh5GMlqcUHjrFeiU'
}
export default config;