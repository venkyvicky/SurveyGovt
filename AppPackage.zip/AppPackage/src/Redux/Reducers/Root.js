import {GET_VILLAGES,GET_VILLAGES_ALT,SET_VILLAGES,SET_VILLAGES_ALT,SET_VILLAGE_PUSH,HNDL_LOGIN,SET_STATUS,SET_CONSUMER_DB,SET_CONSUMER_PUSH, CLEAR_CONSUMER_PUSH} from '../Actions/Actions';
import moment from 'moment';

const initialState = {
  villages: [],
  villagesAlt: [],
  consumerDb: [],
  user: [],
  village: [],
  villageAlt: [],
  installationStatus: 'new',
  lastUpdated: '',
  villagePushed: false,
  consumerPushed: false,
  consumerToPush: [],
};

function rootReducer(state = initialState, action) {
  switch (action.type) {
    case GET_VILLAGES:
      return Object.assign({}, state, {
        villages: action.payload
      });
    case SET_CONSUMER_DB:
      return Object.assign({}, state, {
        consumerDb: action.payload
      });
    case GET_VILLAGES_ALT:
      return Object.assign({}, state, {
        villagesAlt: action.payload
      });
    case SET_VILLAGES:
      return Object.assign({}, state, {
        village: action.payload
      });
    case SET_VILLAGES_ALT:
      return Object.assign({}, state, {
        villageAlt: action.payload
      });
    case SET_VILLAGE_PUSH:
      return Object.assign({}, state, {
        villagePushed: action.payload
      });
    case HNDL_LOGIN:
      return Object.assign({}, state, {
        user: action.payload,
      });
    case SET_STATUS:
      return Object.assign({}, state, {
        installationStatus: action.payload.status,
        lastUpdated: action.payload.timestamp
      });
    case SET_CONSUMER_PUSH:
      return Object.assign({}, state, {
        consumerToPush: state.consumerToPush.concat(action.payload)
      });
    case CLEAR_CONSUMER_PUSH:
      return Object.assign({}, state, {
        consumerToPush: []
      });   
    default:
      return state;
  }
}
export default rootReducer;
