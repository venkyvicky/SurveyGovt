import logger from 'redux-logger';
import rootReducer from './Reducers/Root';
import {createStore, applyMiddleware} from 'redux';
import {persistStore, persistReducer} from 'redux-persist';
import AsyncStorage from '@react-native-community/async-storage';
import FSStorage from 'redux-persist-fs-storage';
import SQLiteStorage from 'redux-persist-sqlite-storage';
import SQLite from 'react-native-sqlite-storage';
import { createRealmPersistStorage } from "@bankify/redux-persist-realm";

const storeEngine = SQLiteStorage(SQLite);

const persistConfig = {
  key: 'root',
  storage: createRealmPersistStorage(),
};
const persistedReducer = persistReducer(persistConfig, rootReducer);

export let store = createStore(persistedReducer, applyMiddleware(logger));
export let persistor = persistStore(store);
