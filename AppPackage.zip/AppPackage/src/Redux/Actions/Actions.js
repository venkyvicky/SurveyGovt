export const GET_VILLAGES = 'GET_VILLAGES';
export function GetVillages(payload) {
  return {
    type: GET_VILLAGES,
    payload
  };
}

export const GET_VILLAGES_ALT = 'GET_VILLAGES_ALT';
export function GetVillagesAlt(payload) {
  return {
    type: GET_VILLAGES_ALT,
    payload
  };
}

export const HNDL_LOGIN = 'HNDL_LOGIN';
export function HndlLogin(payload) {
  return {
    type: HNDL_LOGIN,
    payload
  };
}

export const SET_VILLAGES = 'SET_VILLAGES';
export function SetVillages(payload) {
  return {
    type: SET_VILLAGES,
    payload
  };
}

export const SET_VILLAGES_ALT = 'SET_VILLAGES_ALT';
export function SetVillagesAlt(payload) {
  return {
    type: SET_VILLAGES_ALT,
    payload
  };
}

export const SET_VILLAGE_PUSH = 'SET_VILLAGE_PUSH';
export function SetVillagePush(payload) {
  return {
    type: SET_VILLAGE_PUSH,
    payload
  };
}

export const SET_STATUS = 'SET_STATUS';
export function SetStatus(payload) {
  return {
    type: SET_STATUS,
    payload
  };
}

export const SET_CONSUMER_DB = 'SET_CONSUMER_DB';
export function SetConsumerDb(payload) {
  return {
    type: SET_CONSUMER_DB,
    payload
  };
}

export const SET_CONSUMER_PUSH = 'SET_CONSUMER_PUSH';
export function SetConsumerPush(payload) {
  return {
    type: SET_CONSUMER_PUSH,
    payload
  };
}

export const CLEAR_CONSUMER_PUSH = 'CLEAR_CONSUMER_PUSH';
export function ClearConsumerPush(payload) {
  return {
    type: CLEAR_CONSUMER_PUSH,
    payload
  };
}