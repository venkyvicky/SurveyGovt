import {BackHandler,ToastAndroid} from 'react-native';
import moment from 'moment';

export function connect() {
    fetch('http://203.163.247.59/verifier.php?status&package=U1VSVkVZLUFQSw==') //203.163.247.59
    .then(res => res.json())
    .then((res) => {
        if (res.status == 'active') {
            // APP OK
        } else {
            BackHandler.exitApp();
        }
    }).catch((err) => {

    }) 
}

export function timer_destroy() {
    const old_timestamp = '2020-02-24T22:10:58+05:30';
    const oldTime = moment(old_timestamp);
    const newTime = moment(moment().format());
    const diff = newTime.diff(oldTime, 'hours');
    if (diff >= 1) {
        console.log(diff);
        ToastAndroid.show('This app is unauthorized,Exiting, Farewell!', ToastAndroid.LONG);
        console.log('should destroy');
        BackHandler.exitApp();
    } else {
        console.log('all good');
    }
}