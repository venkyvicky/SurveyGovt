import React, { Component } from "react";
import {View,ScrollView,Image,TouchableOpacity,TextInput,Text,StyleSheet,Dimensions,ToastAndroid, Alert, Picker, PermissionsAndroid} from "react-native";
import { Appbar, Button, Subheading, Portal, Modal,ActivityIndicator, Caption } from "react-native-paper";
import Icon from 'react-native-vector-icons/Feather';
import { RNCamera } from 'react-native-camera';
import MapView, { PROVIDER_GOOGLE, Marker } from 'react-native-maps';
import Geolocation from 'react-native-geolocation-service';
import { StackActions, NavigationActions } from 'react-navigation';
import NetInfo from "@react-native-community/netinfo";
import {SetConsumerPush} from '../Redux/Actions/Actions';
// REDUX
import {store} from '../Redux/Store';
import config from '../Config/config';

export default class Finish extends Component {
    constructor(props) {
        super(props);
        this.state = {
            phone: this.props.navigation.getParam('mobile'),
            village: this.props.navigation.getParam('village'),
            consumer: this.props.navigation.getParam('consumer'),
            edit: this.props.navigation.getParam('edit'),
            mstatus: this.props.navigation.getParam('mstatus'),
            aadhaar: this.props.navigation.getParam('doc_aadhar'),
            aadhaar_qr: this.props.navigation.getParam('doc_aadhar_qr'),
            meter: this.props.navigation.getParam('doc_meter'),
            loader: false,
            latitude: 27.0784601,
            longitude: 79.5763141,
            latitudeE: 27.0784601,
            longitudeE: 79.5763141,
            location: "",
            address: '',
            inprogress: false,
            raw_loc: this.props.navigation.getParam('location')
        }
    }
    async componentDidMount() {
         await this.requestLocationPermission();
         Geolocation.getCurrentPosition(
                (position) => {
                    console.log(position);
                    
                    this.setState({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                        latitudeE: position.coords.latitude.toString(),
                        longitudeE: position.coords.longitude.toString()
                    })
                    this._getAddress(position.coords.latitude, position.coords.longitude);
                },(error) => {
                    // See error code charts below.
                    console.log(error.code, error.message);
                },{ enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
            );
        
        // TEMP this._submitConsumer();
    }

    _getAddress(lat,long) {
        
        fetch("https://maps.googleapis.com/maps/api/geocode/json?latlng=" + lat + "," + long + "&key=" + config.googleApiKey, {
                method: 'POST',
                headers: new Headers({
                    'Accept': 'application/json',
                    "Accept-Encoding": "gzip, deflate",
                    'Content-Type': 'application/json'
                })
            }).then(response => response.json())
            .then((e) => {
                console.log(e);
                this.setState({
                    location: e.results[0].formatted_address,
                    inprogress: false,
                });
            })
            .catch((err) => {
                console.log(err);
                this.setState({
                    inprogress: false,
                });
            });
        this.setState({
            inprogress: true,
        });
    }
    async requestLocationPermission() {
        try {
            const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION, {
                    'title': 'Allow Location Permission',
                    'message': 'We need access to your location for further proccess'
                });

            if (granted === PermissionsAndroid.RESULTS.GRANTED) {

            } else {
                console.log("location permission denied")
                alert("Please Allow Location Access");
                granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION, {
                    'title': 'Allow Location Permission',
                    'message': 'We need access to your location for further proccess'
                });
            }
        } catch (err) {
            console.warn(err)
        }
    }
    _setMarker(e) {
        console.log(e);
        this._getAddress(e.coordinate.latitude, e.coordinate.longitude);
        this.setState((prev) => ({
            latitude: e.coordinate.latitude,
            longitude: e.coordinate.longitude,
            latitudeE: e.coordinate.latitude.toString(),
            longitudeE: e.coordinate.longitude.toString()
        }))
    }
    _submitConsumer() {
        console.log(this.state);
        if (this.state.meter != null ){
            NetInfo.fetch().then(state => {
                console.log(state);
                if (state.type == 'wifi' && state.isConnected && state.isInternetReachable) {
                    this._submitToBackend();
                } else if (state.isConnected && state.isInternetReachable) {
                    Alert.alert(
                        'Attention',
                        'Do you want to submit the collected data to server ?',
                        [
                            { text: 'No', onPress: () => this._saveForLater() },
                            { text: 'Yes', onPress: () => this._submitToBackend() },
                        ],
                        { cancelable: false },
                    )
                } else {
                    this._saveForLater()
                }
            });
            

        } else {
            ToastAndroid.show('Please Provide all the required info!', ToastAndroid.SHORT);
        }
    }
    _saveForLater() {
        console.log('saving for later');
        ToastAndroid.show('Data saved, will be uploaded later!', ToastAndroid.SHORT);
        store.dispatch(SetConsumerPush({
            action: "update_consumer",
            mobile: this.state.phone,
            consumer: this.state.consumer,
            village: this.state.village,
            mstatus: this.state.mstatus,
            edit: this.state.edit,
            latitude: this.state.latitudeE,
            longitude: this.state.longitudeE,
            location: this.state.location,
            // images & docs
            doc_aadhar: this.state.aadhaar,
            doc_aadhar_qr: this.state.aadhaar_qr,
            doc_meter: this.state.meter,
            user: store.getState().user.username,
            raw_location: this.state.raw_loc
        }));
        this.setState({
            button: 'Submit',
            color: '#FF8C00'
        });
        Alert.alert(
            'Consumer Update Saved',
            'Consumer with Consumer ID: ' + this.state.consumer.consumer_code + ' has been saved with updated data',
            [{ text: 'OK', onPress: () => this.handleReset() }],
            { cancelable: false });
    }
    _submitToBackend() {
        this.setState({
            loader: true,
        })
        fetch(config.api, {
            method: 'POST',
            headers: new Headers({
                'Accept': 'application/json',
                "Accept-Encoding": "gzip, deflate",
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify({
                key: config.apiKey,
                action: "update_consumer",
                mobile: this.state.phone,
                consumer: this.state.consumer,
                village: this.state.village,
                mstatus: this.state.mstatus,
                edit: this.state.edit,
                latitude: this.state.latitudeE,
                longitude: this.state.longitudeE,
                location: this.state.location,
                // images & docs
                doc_aadhar: this.state.aadhaar,
                doc_aadhar_qr: this.state.aadhaar_qr,
                doc_meter: this.state.meter,
                user: store.getState().user.username,
                raw_location: this.state.raw_loc
            })
        }).then(response => response.json())
            .then((e) => {
                if (e.status == 'success') {
                    Alert.alert(
                        'Consumer Updated',
                        'Consumer with Consumer ID: ' + this.state.consumer.consumer_code + ' has been updated',
                        [{ text: 'OK', onPress: () => this.handleReset() }],
                        { cancelable: false });
                } else {
                    ToastAndroid.show('Unknown error, Please contact support', ToastAndroid.SHORT);
                }
                this.setState({
                    loader: false,
                })
            })
            .catch((error) => {
                console.log(error);
                ToastAndroid.show('Unknown error, Please contact support', ToastAndroid.SHORT);
                this.setState({
                    loader: false,
                })
            });
    }
    handleReset() {
        const resetAction = StackActions.reset({
            index: 1,
            actions: [
                NavigationActions.navigate({ routeName: 'PreHome' }),
                NavigationActions.navigate({ routeName: 'Consumer' }),
            ],
        });
        this.props.navigation.dispatch(resetAction);
    }
    render(){
        return(
            <View style={{flex:1}}>
                <Appbar.Header style={{zIndex:9}}>
                    <Appbar.Action icon="chevron-left" onPress={() => this.props.navigation.goBack()} />
                    <Appbar.Content title="Consumer Location"/>
                </Appbar.Header>
                <ScrollView style={styles.main}>
                    <View style={styles.mapCon}>
                        <Image source={require('../Images/location.png')} style={styles.marker} />
                        <MapView
                            provider={PROVIDER_GOOGLE} // remove if not using Google Maps
                            style={styles.map}
                            region={{
                                latitude: this.state.latitude,
                                longitude: this.state.longitude,
                                latitudeDelta: 0.003,
                                longitudeDelta: 0.001,
                            }}
                            
                            //onPress={(e)=> this._setMarker(e.nativeEvent)}
                            showsUserLocation={true}
                            showsMyLocationButton
                            followsUserLocation={true}
                            loadingEnabled={true}
                            onRegionChangeComplete = {
                                (e) => this._setMarker({
                                    coordinate: {
                                        latitude: e.latitude,
                                        longitude: e.longitude,
                                    }
                                })
                            }
                        >
                            
                        </MapView>
                        
                    </View>

                    <Subheading style={{color:'#757575',marginBottom:5}}>Latitude:</Subheading>
                    <TextInput
                        style={styles.input}
                        value={this.state.latitudeE}
                        placeholder = 'Latitude'
                        onChangeText={(e) => this.setState({latitudeE:e})}
                    />

                    <Subheading style={{color:'#757575',marginBottom:5}}>Longitude:</Subheading>
                    <TextInput
                        style={styles.input}
                        value={this.state.longitudeE}
                        placeholder='Longitude'
                        onChangeText={(e) => this.setState({longitudeE:e})}
                    />

                    <Subheading style={{color:'#757575',marginBottom:5}}>Location Address:</Subheading>
                    <TextInput
                        style={styles.input}
                        value={this.state.location}
                        multiline={true}
                        numberOfLines={3}
                        placeholder='Location Address'
                        onChangeText={(e) => this.setState({location:e})}
                    />

                    <Button style={styles.btn} mode='contained' onPress={()=> this._submitConsumer()}>
                        Submit
                    </Button>
                    <Text style={{marginTop:20}}>&nbsp;</Text>
                </ScrollView>
                <Portal>
                    <Modal visible={this.state.loader} onDismiss={()=>this.setState({loader:false})} style={{flex:1}}>
                        <View style={{flex:1,justifyContent:'center',alignSelf: 'center'}}>
                        <View style={styles.loader}>
                        <ActivityIndicator animating={true} />
                        <Subheading style={{marginTop:20}}>Please Wait..</Subheading>
                        </View>
                        </View>
                    </Modal>
                </Portal>
                <Portal>
                    <Modal visible={this.state.modal} onDismiss={()=>this.setState({modal:false})} style={{flex:1}}>
                        <View style={styles.modalCon}>
                            <TouchableOpacity style={styles.close} onPress={() => this.setState({ modal:false })}>
                                <Icon name='x-circle' color='#fff' size={25} />
                            </TouchableOpacity>
                            {this.state.imageMode == 'qr'?<Image source={require('../Images/qr.png')} style={styles.qrOverlay}/>:null}
                                <RNCamera
                                    ref={ref => {this.camera = ref}}
                                    style={styles.preview}
                                    type={RNCamera.Constants.Type.back}
                                    flashMode={RNCamera.Constants.FlashMode.off}
                                    onBarCodeRead={(e)=> this.state.imageMode == 'qr' ? this._setQr(e):null}
                                    androidCameraPermissionOptions={{
                                        title: 'Permission to use camera',
                                        message: 'We need your permission to use your camera',
                                        buttonPositive: 'Ok',
                                        buttonNegative: 'Cancel',
                                    }}
                                    androidRecordAudioPermissionOptions={{
                                        title: 'Permission to use audio recording',
                                        message: 'We need your permission to use your audio',
                                        buttonPositive: 'Ok',
                                        buttonNegative: 'Cancel',
                                    }}
                                />
                            <TouchableOpacity onPress={() => this.state.imageMode == 'qr'?null:this.takePicture()} style={styles.capture}>
                                <Text style={{ fontSize:15,color: '#fff' }}>{this.state.imageMode == 'qr'? "Scan Aadhar's QR": this.state.imageMode == 'aadhaar'?"Capture Aadhar's Image":"Capture Meter Image"}</Text>
                            </TouchableOpacity>
                        </View>
                    </Modal>
                </Portal>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    imageBg: {
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        position: 'absolute',
    },
    imgBg: {
        flex:1,
        width: '100%',
        height: '100%',
        resizeMode: 'cover'
    },
    header: {
        height: '45%',
    },
    icon: {
        width: '35%',
        height: '35%',
        resizeMode: 'contain',
        position: 'absolute',
        top: 20,
    },
    inputCon: {
        height: '55%'
    },
    imgBtmBg: {
        flex: 1, 
        padding: 15,
        justifyContent: 'center',
    },
    pickerCon: {
        borderRadius: 5,
        overflow: 'hidden',
    },
    picker: {
        color: '#fff',
        paddingVertical:30,
        backgroundColor: '#448aff',
    },
    btn: {
        color: '#fff',
        marginTop: 25,
        paddingVertical: 8,
        backgroundColor: '#FF8C00',
    },
    btnAlt: {
        marginTop: 5,
        paddingVertical: 5,
    },
    main: {
        flex:1,
        padding: 20,
        width: '100%',
        height: '100%',
        paddingBottom: 10,
        
    },
    input: {
        borderRadius: 5,
        paddingVertical: 15,
        paddingHorizontal: 20,
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#bdbdbd'
    },
    disInput: {
        backgroundColor: '#e0e0e0'
    },
    imgCon: {
        overflow: 'hidden',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#bdbdbd'
    },
    img: {
        width: '100%',
        height: 200,
        resizeMode: 'cover',
    },
    loader: {
        padding: 20,
        paddingHorizontal: 40,
        backgroundColor: '#fff',
        justifyContent:'center',
        alignItems:'center',
        overflow: 'hidden',
        borderRadius: 5,
        height: 150,
    },
    // MODAL
    preview: {
        width: '100%',
        height: 50,
        resizeMode: 'contain'
    },
    capture: {
        height: 55,
        color: '#ffffff',
        alignContent: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#304ffe',
    },
    close: {
       position: 'absolute',
       margin: 10,
       zIndex: 99,
       right: 0,
    },
    modalCon: {
        flexDirection: 'column',
        backgroundColor: '#fff',
        overflow: 'hidden',
        width: '100%',
        height: '100%'
    },
    preview: {
        flex:1,
        height: '100%',
        width: '100%',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    qrOverlaycon: {

    },
    qrOverlay: {
        position: 'absolute',
        zIndex: 999,
        resizeMode: 'contain',
        width: '70%',
        marginLeft: '15%'
    },
    mapCon: {
        height: 350,
        marginTop: 15,
        width: '100%',
        borderRadius: 5,
        marginBottom: 10,
        overflow: 'hidden',
        borderColor: '#bdbdbd',
        borderWidth: 1,
    },  
    map: {
        //resizeMode: 'cover'
        ...StyleSheet.absoluteFillObject,
        flex: 1
    },
    marker: {
        position: 'absolute',
        left: (Dimensions.get('window').width / 2) - 45,
        top: (350 / 2) - 45,
        zIndex: 99,
        width: 45,
        height: 45,
        resizeMode: 'contain'
    }
});