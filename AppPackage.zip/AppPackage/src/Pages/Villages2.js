import React, {Component,Fragment} from 'react';
import {View, ImageBackground, Image, Picker, StyleSheet, Dimensions, ToastAndroid} from 'react-native';
import { Button, Appbar,Caption, Subheading,Portal, Modal,ActivityIndicator } from 'react-native-paper';
import SearchableDropdown from 'react-native-searchable-dropdown';
// REDUX
import {store} from '../Redux/Store';
import {GetVillages, SetVillagesAlt} from '../Redux/Actions/Actions';
// CONFIG
import config from '../Config/config';

export default class Villages2 extends Component {
    constructor() {
        super();
        this.state = {
            loader: false,
            village: [],
            villages: store.getState().villagesAlt
        }
    }
    componentDidMount(){
        store.subscribe((e) => {
            this.setState({
                villages: store.getState().villagesAlt
            })
        })
        
    }
    _selectVillage() {
        if (this.state.village.length != 0){
            store.dispatch(SetVillagesAlt({
                village: this.state.village,
                // location: this.state.geo.coords
            }));
            this.props.navigation.navigate('Consumer',{village:this.state.village});
        } else {
            ToastAndroid.show('Please select a village first!', ToastAndroid.SHORT);
        }
    }
    render(){
        return(
            <View style={{flex:1}}>
                <Appbar.Header style={{ zIndex: 9 }}>
                    <Appbar.Action
                        icon="chevron-left"
                        onPress={() => this.props.navigation.goBack()}
                    />
                    <Appbar.Content title="Select Village" />
                </Appbar.Header>
                <View style={styles.main}>
                    <View style={styles.inputCon}>
                            <View style={styles.pickerCon}>
                                <Fragment>
                                    <SearchableDropdown
                                        onItemSelect={(item) => {
                                            this.setState({
                                                village: item
                                            })
                                        }}
                                        containerStyle={{ padding: 5 }}
                                        itemStyle={{
                                            padding: 10,
                                            marginTop: 2,
                                            backgroundColor: '#ddd',
                                            borderColor: '#bbb',
                                            borderWidth: 1,
                                            borderRadius: 5,
                                        }}
                                        itemTextStyle={{ color: '#222' }}
                                        itemsContainerStyle={{ maxHeight: 140 }}
                                        items={this.state.villages}
                                        resetValue={false}
                                        textInputProps={{
                                            placeholder: "Select Village",
                                            underlineColorAndroid: "transparent",
                                            style: {
                                                padding: 12,
                                                borderWidth: 1,
                                                borderColor: '#ccc',
                                                borderRadius: 5,
                                            },
                                            // onTextChange: text => console.log(text)
                                        }}
                                        listProps={{
                                            nestedScrollEnabled: true,
                                        }}
                                    />
                                </Fragment>
                            </View>
                            <View style={{paddingHorizontal:5}}>
                                <View style={{marginTop:10}}>
                                    <Caption>
                                    Name: {this.state.village.village_name}, Code: {this.state.village.village_code}
                                        {'\n'}Zone: {this.state.village.zone}, Circle: {this.state.village.circle}
                                        {'\n'}Division: {this.state.village.division}. Subdivision: {this.state.village.subdivision}
                                    </Caption>
                                </View>
                                <Button style={styles.btn} contentStyle={{height:50}} mode='contained' onPress={()=> this._selectVillage()}>
                                    Next
                                </Button>
                            </View>
                    </View>
                </View>
                <Portal>
                    <Modal visible={this.state.loader} onDismiss={()=>this.setState({loader:false})} style={{flex:1}}>
                        <View style={{flex:1,justifyContent:'center',alignSelf: 'center'}}>
                        <View style={styles.loader}>
                        <ActivityIndicator animating={true} />
                        <Subheading style={{marginTop:20}}>Please Wait..</Subheading>
                        </View>
                        </View>
                    </Modal>
                </Portal>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    main: {
        flex:1,
        justifyContent:'center',
        alignContent: 'center',
        alignItems: 'center'    
    },
    imgBg: {
        flex:1,
        width: '100%',
        height: '100%',
        resizeMode: 'cover'
    },
    header: {
        height: '45%',
    },
    icon: {
        width: '35%',
        height: '35%',
        resizeMode: 'contain',
        position: 'absolute',
        top: 20,
    },
    inputCon: {
        width: '100%',
        padding: 20,
    },
    imgBtmBg: {
        flex: 1, 
        padding: 15,
        justifyContent: 'center',
    },
    pickerCon: {
        borderRadius: 5,
        overflow: 'hidden',
    },
    picker: {
        color: '#fff',
        paddingVertical:30,
        backgroundColor: '#448aff',
    },
    btn: {
        color: '#fff',
        marginTop: 25,
        backgroundColor: '#FF8C00',
    },
    loader: {
        padding: 20,
        paddingHorizontal: 40,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
        borderRadius: 5,
        height: 150,
    },
});