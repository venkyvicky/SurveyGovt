import React, {Component} from 'react';
import {View, TextInput, Text, ImageBackground, TouchableOpacity, Image, Picker, StyleSheet, Dimensions, ToastAndroid, Alert} from 'react-native';
import { Appbar, Button, Subheading, Portal, Modal } from 'react-native-paper';
import Icon from 'react-native-vector-icons/Feather';
import { RNCamera } from 'react-native-camera';
import NetInfo from "@react-native-community/netinfo";
import config from '../Config/config';
// REDUX
import {store} from '../Redux/Store';
import {SetVillages, SetVillagePush} from '../Redux/Actions/Actions';

export default class Location extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modal: false,
            image: null,
            village: this.props.navigation.getParam('village'),
            location: this.props.navigation.getParam('location'),
            button: 'Submit',
            color: '#FF8C00',
        }
    }
    _submitLocation() {
        if (this.state.image != null){
            console.log(this.state);
            this.setState({
                button: 'Please Wait..',
                color: '#bdbdbd'
            });
            store.dispatch(SetVillages({
                village: this.state.village,
                location: this.state.location,
                image: this.state.image
            }));
            NetInfo.fetch().then(state => {
                console.log(state);
                if (state.type == 'wifi' && state.isConnected && state.isInternetReachable) {
                    this._submitToBackend();
                } else if (state.isConnected && state.isInternetReachable) {
                    Alert.alert(
                        'Attention',
                        'Do you want to submit the collected data to server ?',
                        [
                            { text: 'No', onPress: () => this._saveForLater()},
                            { text: 'Yes', onPress: () => this._submitToBackend()},
                        ],
                        { cancelable: false },
                        )
                } else {
                    this._saveForLater()
                }
            });
            
        } else {
            ToastAndroid.show("Please capture location's picture first!", ToastAndroid.SHORT);
        }
    }
    _submitToBackend() {
        fetch(config.api, {
            method: 'POST',
            headers: new Headers({
                'Accept': 'application/json',
                "Accept-Encoding": "gzip, deflate",
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify({
                key: config.apiKey,
                action: "update_village",
                village: this.state.village,
                location: this.state.location,
                image: this.state.image,
            })
        }).then(response => response.json())
            .then((e) => {
                console.log(e);
                if (e.status == 'success') {
                    this.setState({
                        button: 'Submit',
                        color: '#FF8C00'
                    });
                    this.props.navigation.navigate('PreHome');
                } else {
                    ToastAndroid.show('Sorry, something went wrong. Contact Support', ToastAndroid.SHORT);
                    this.setState({
                        button: 'Try Again',
                        color: '#FF8C00'
                    });
                }
            }).catch((error) => {
                console.error(error);
                ToastAndroid.show('Sorry, something went wrong. Contact Support', ToastAndroid.SHORT);
                this.setState({
                    button: 'Try Again',
                    color: '#FF8C00'
                });
            });
    }
    _saveForLater() {
        console.log('saving for later');
        ToastAndroid.show('Data saved, will be uploaded later!', ToastAndroid.SHORT);
        store.dispatch(SetVillagePush(true));
        this.setState({
            button: 'Submit',
            color: '#FF8C00'
        });
        this.props.navigation.navigate('PreHome');
    }
    takePicture = async(mode) => {
        if (this.camera) {
            const options = { quality: 0.5, base64: true };
            const data = await this.camera.takePictureAsync(options);
            this.setState({
                image: "data:image/jpg;base64," + data.base64,
                modal: false,
            });
        }
    };
    render(){
        return(
            <View style={{flex:1}}>
                <Appbar.Header style={{zIndex:9}}>
                    <Appbar.Action icon="chevron-left" onPress={() => this.props.navigation.goBack()} />
                    <Appbar.Content title="Location&apos;s Picture"/>
                </Appbar.Header>
                <View style={styles.main}>
                    <Subheading style={{color:'#757575',marginBottom:5}}>Capture location's photo:</Subheading>
                    <View style={styles.mapCon}>
                        <Image style={styles.map} source={{uri:this.state.image}}/>
                    </View>

                    <Button style={styles.btnAlt} contentStyle={{height:50}} mode='contained' onPress={()=> this.setState({modal:true})}>
                        Open Camera
                    </Button>
                    <Button style={[styles.btn, {backgroundColor:this.state.color}]} contentStyle={{height:50}} mode='contained' onPress={()=> this._submitLocation()}>
                        {this.state.button}
                    </Button>
                </View>
                <Portal>
                    <Modal visible={this.state.modal} onDismiss={()=>this.setState({modal:false})} style={{flex:1}}>
                        <View style={styles.modalCon}>
                            <TouchableOpacity style={styles.close} onPress={() => this.setState({ modal:false })}>
                                <Icon name='x-circle' color='#fff' size={25} />
                            </TouchableOpacity>
                                <RNCamera
                                    ref={ref => {this.camera = ref}}
                                    style={styles.preview}
                                    type={RNCamera.Constants.Type.back}
                                    flashMode={RNCamera.Constants.FlashMode.off}
                                    androidCameraPermissionOptions={{
                                        title: 'Permission to use camera',
                                        message: 'We need your permission to use your camera',
                                        buttonPositive: 'Ok',
                                        buttonNegative: 'Cancel',
                                    }}
                                    androidRecordAudioPermissionOptions={{
                                        title: 'Permission to use audio recording',
                                        message: 'We need your permission to use your audio',
                                        buttonPositive: 'Ok',
                                        buttonNegative: 'Cancel',
                                    }}
                                />
                            <TouchableOpacity onPress={() => this.takePicture()} style={styles.capture}>
                                <Text style={{ fontSize:15,color: '#fff' }}>Capture</Text>
                            </TouchableOpacity>
                        </View>
                    </Modal>
                </Portal>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    imageBg: {
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        position: 'absolute',
    },
    imgBg: {
        flex:1,
        width: '100%',
        height: '100%',
        resizeMode: 'cover'
    },
    header: {
        height: '45%',
    },
    icon: {
        width: '35%',
        height: '35%',
        resizeMode: 'contain',
        position: 'absolute',
        top: 20,
    },
    inputCon: {
        height: '55%'
    },
    imgBtmBg: {
        flex: 1, 
        padding: 15,
        justifyContent: 'center',
    },
    btn: {
        color: '#fff',
        marginTop: 20,
        backgroundColor: '#FF8C00',
    },
    btnAlt: {
        marginTop: 10,
    },
    main: {
        flex:1,
        padding: 20,
        width: '100%',
        height: '100%',
        paddingTop: 10,
    },
    mapCon: {
        overflow: 'hidden',
        borderRadius: 5,
        height: '65%',
        borderWidth: 1,
        borderColor: '#bdbdbd'
    },  
    map: {
        resizeMode: 'cover',
        height:'100%',
        width: '100%',
    },
    input: {
        marginTop: 20,
        borderRadius: 5,
        paddingVertical: 15,
        paddingHorizontal: 20,
        backgroundColor: '#fff',
        textAlignVertical: 'top',
    },
    // MODAL
    preview: {
        width: '100%',
        height: 50,
        resizeMode: 'contain'
    },
    capture: {
        height: 55,
        color: '#ffffff',
        alignContent: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FF8C00',
    },
    close: {
       position: 'absolute',
       margin: 10,
       zIndex: 99,
       right: 0,
    },
    modalCon: {
        flexDirection: 'column',
        backgroundColor: '#fff',
        overflow: 'hidden',
        width: '100%',
        height: '100%'
    },
    preview: {
        flex:1,
        height: '100%',
        width: '100%',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
});