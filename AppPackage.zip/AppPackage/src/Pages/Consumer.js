import React, { Component } from "react";
import {View,ScrollView,TouchableOpacity,TextInput,Text,StyleSheet,Dimensions,ToastAndroid, Alert} from "react-native";
import { Appbar, Button, Subheading, Portal, Modal,ActivityIndicator, Headline } from "react-native-paper";
import Icon from 'react-native-vector-icons/Feather';
// REDUX
import { store } from "../Redux/Store";
import config from '../Config/config';
export default class Consumer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loader: false,
      raw: null,
      consumerNo: '',
      scno: '',
      bookcode: '',
      consumer: '',
      father: '',
      address: '',
      meter: '',
      village: store.getState().villageAlt.length == 0 ? this.props.navigation.getParam("village"): store.getState().villageAlt.village,
      // location: store.getState().village.length == 0 ? this.props.navigation.getParam("location"): store.getState().village.location,
      meterid: "",
    };
  }
  /* componentDidMount(){
    this.setState({
      loader: false,
      raw: null,
      consumerNo: '',
      scno: '',
      bookcode: '',
      consumer: '',
      father: '',
      address: '',
      meter: '',
      village: store.getState().villageAlt.length == 0 ? this.props.navigation.getParam("village"): store.getState().villageAlt.village,
      // location: store.getState().village.length == 0 ? this.props.navigation.getParam("location"): store.getState().village.location,
      meterid: "",
    })
  }*/
  _submitLocation() {
    console.log(this.state);
    if (this.state.raw != null) {
      var data = {
        name: this.state.consumer,
        father: this.state.father,
        address: this.state.address
      };
      this.props.navigation.navigate("Documents",{village:this.state.village,consumer:this.state.raw,edit:data});
    } else {
      ToastAndroid.show('Please get Consumer Data first', ToastAndroid.SHORT);
    }
  }
  _getConsumer(){
    if(this.state.consumerNo != ''){
      const consumers = Object.values(store.getState().consumerDb);
      const keys = Object.keys(store.getState().consumerDb);
      let i = consumers.length;
      let result = [];
      for (i = i - 1; i >= 0; i--) {
        if (consumers[i].consumer_code.includes(this.state.consumerNo)) {
          var e = consumers[i];
          this.setState({
            raw: e,
            scno: e.consumer_scno,
            bookcode: e.consumer_bookcode,
            consumer: e.consumer_name,
            father: e.consumer_father,
            meterid: e.consumer_meterid,
            address: e.consumer_address,

          });
        }
      }
    } else {
      ToastAndroid.show('Please enter an Consumer Number First!', ToastAndroid.SHORT);
    }
  }
  _getConsumer_alt() {
    if (this.state.meterid != '') {
      const consumers = Object.values(store.getState().consumerDb);
      const keys = Object.keys(store.getState().consumerDb);
      let i = consumers.length;
      let result = [];
      for (i = i - 1; i >= 0; i--) {
        if (consumers[i].consumer_meterid.includes(this.state.meterid)) {
          var e = consumers[i];
          this.setState({
            raw: e,
            scno: e.consumer_scno,
            bookcode: e.consumer_bookcode,
            consumer: e.consumer_name,
            father: e.consumer_father,
            consumerNo: e.consumer_code,
            address: e.consumer_address,

          });
        }
      }
    } else {
      ToastAndroid.show('Please enter an Meter ID First!', ToastAndroid.SHORT);
    }
  }
  render() {
    return (
      <View style={{ flex: 1 }}>
        <Appbar.Header style={{ zIndex: 9 }}>
          <Appbar.Action
            icon="chevron-left"
            onPress={() => this.props.navigation.goBack()}
          />
          <Appbar.Content title="Consumer Details" />
        </Appbar.Header>
        <ScrollView style={styles.main}>
          <Subheading style={{ color: "#757575", marginBottom: 5 }}>
            Selected Village (Auto Filled):
          </Subheading>
          <Headline style={{marginBottom:15}}>{this.state.village.village_name}</Headline>

          <Subheading style={{ color: "#757575", marginBottom: 5 }}>
            Consumer No:
          </Subheading>
          <View style={styles.searchCon}>
            <TextInput
              style={styles.inputAlt}
              value={this.state.consumerNo}
              placeholder="Consumer Number"
              onChangeText={e => this.setState({ consumerNo: e })}
              keyboardType='numeric'
            />
            <TouchableOpacity onPress={() => this._getConsumer()}>
              <Icon name='search' style={styles.search}/>
            </TouchableOpacity>
          </View>

          <Subheading style={{ color: "#757575", marginBottom: 5 }}>
            Meter ID:
          </Subheading>
          <View style={styles.searchCon}>
            <TextInput
              style={styles.inputAlt}
              value={this.state.meterid}
              placeholder="Meter ID"
              onChangeText={e => this.setState({ meterid: e })}
              keyboardType='numeric'
            />
            <TouchableOpacity onPress={() => this._getConsumer_alt()}>
              <Icon name='search' style={styles.search}/>
            </TouchableOpacity>
          </View>

          <Subheading style={{ color: "#757575", marginBottom: 5 }}>
            Consumers Name (Auto Filled):
          </Subheading>
          <TextInput
            style={[styles.input, styles.disInput]}
            value={this.state.consumer}
            onChangeText={e => this.setState({ consumer: e })}
            placeholder="Consumers Name"
            editable={true}
          />
          
          <Subheading style={{ color: "#757575", marginBottom: 5 }}>
            Father's Name (Auto Filled):
          </Subheading>
          <TextInput
            style={[styles.input, styles.disInput]}
            value={this.state.father}
            onChangeText={e => this.setState({ father: e })}
            placeholder="Fathers Name"
            editable={true}
          />
          <Subheading style={{ color: "#757575", marginBottom: 5 }}>
            Address (Auto Filled):
          </Subheading>
          <TextInput
            multiline={true}
            numberOfLines={3}
            style={[
              styles.input,
              styles.disInput,
              { textAlignVertical: "top" }
            ]}
            value={this.state.address}
            onChangeText={e => this.setState({ address: e })}
            placeholder="Address"
            editable={true}
          />

          <Button
            style={styles.btn}
            mode="contained"
            onPress={() => this._submitLocation()}
          >
            Next
          </Button>
          <Text>&nbsp;</Text>
        </ScrollView>
        <Portal>
          <Modal visible={this.state.loader} onDismiss={()=>this.setState({loader:false})} style={{flex:1}}>
            <View style={{flex:1,justifyContent:'center',alignSelf: 'center'}}>
              <View style={styles.loader}>
              <ActivityIndicator animating={true} />
              <Subheading style={{marginTop:20}}>Please Wait..</Subheading>
            </View>
            </View>
          </Modal>
        </Portal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  imageBg: {
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    position: "absolute"
  },
  imgBg: {
    flex: 1,
    width: "100%",
    height: "100%",
    resizeMode: "cover"
  },
  header: {
    height: "45%"
  },
  icon: {
    width: "35%",
    height: "35%",
    resizeMode: "contain",
    position: "absolute",
    top: 20
  },
  inputCon: {
    height: "55%"
  },
  imgBtmBg: {
    flex: 1,
    padding: 15,
    justifyContent: "center"
  },
  pickerCon: {
    borderRadius: 5,
    overflow: "hidden"
  },
  picker: {
    color: "#fff",
    paddingVertical: 30,
    backgroundColor: "#448aff"
  },
  btn: {
    color: "#fff",
    marginTop: 10,
    paddingVertical: 8,
    backgroundColor: "#FF8C00"
  },
  main: {
    flex: 1,
    width: "100%",
    padding: 20,
    paddingTop: 10
  },
  input: {
    borderRadius: 5,
    marginBottom: 5,
    paddingVertical: 15,
    paddingHorizontal: 20,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#bdbdbd"
  },
  disInput: {
    backgroundColor: "#e0e0e0",
    color: '#000',
    fontWeight: 'bold'
  },
  searchCon: {
    flexDirection: 'row',
    position: 'relative',
    alignItems: 'center',
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#bdbdbd",
    borderRadius: 5,
    marginBottom: 5,
    overflow: 'hidden'
  },
  inputAlt: {
    flexGrow:1,
    paddingVertical: 15,
    paddingHorizontal: 20,
    backgroundColor: "#fff",
  },
  search: {
    fontSize:28,
    zIndex: 9,
    paddingHorizontal:10
  },
  loader: {
    padding: 20,
    paddingHorizontal: 40,
    backgroundColor: '#fff',
    justifyContent:'center',
    alignItems:'center',
    overflow: 'hidden',
    borderRadius: 5,
    height: 150,
  }
});
