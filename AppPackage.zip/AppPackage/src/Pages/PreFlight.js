import React, { Component } from "react";
import { View, ScrollView, Image, TextInput, Text, StyleSheet, Dimensions, TouchableOpacity, Alert, BackHandler, ToastAndroid } from "react-native";
import { Appbar, Button, Subheading, Headline, Badge, ActivityIndicator } from "react-native-paper";
import { store, persistor } from "../Redux/Store";
import {GetVillages, GetVillagesAlt, SetStatus, SetConsumerDb} from '../Redux/Actions/Actions';
import RNRestart from 'react-native-restart';
import config from '../Config/config';
import NetInfo from "@react-native-community/netinfo";
import moment from "moment";
import { connect } from '../Redux/Actions/Connect.js';

export default class PreFlight extends Component {
    constructor() {
        super();
        this.state = {
            status: 'Standing By...',
            loader: true,
        }
    }
    componentDidMount() {
        connect()
        NetInfo.fetch().then(state => {
            if (state.isConnected) {
                Alert.alert(
                    'Welcome',
                    'please allow us a moment to prepare this application for offline usage',
                    [
                        { text: 'Quit App', onPress: () => BackHandler.exitApp()},
                        { text: 'OK', onPress: () => this.fetchData()},
                    ],
                    { cancelable: false },
                );
            }
        });
    }
    fetchData() {
        console.log('Fetching Data...');
        this.setState({
            status: 'Fetching Allowcated Villages...'
        })
        fetch(config.api, {
            method: 'POST',
            headers: new Headers({
                'Accept': 'application/json',
                "Accept-Encoding": "gzip, deflate",
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify({
                key: config.apiKey,
                action: "get_villages",
                feeder_code: store.getState().user.feeder_code,
            })
        }).then(response => response.json())
            .then((e) => {
                store.dispatch(GetVillages(e));
                this.setState({
                    status: 'Fetching Mapped Villages...'
                },() => this.getVlgAlt());

            })
            .catch((error) => {
                console.log(error);
                Alert.alert('Something went wrong','We are facing some technical difficulties at this moment, its maybe because of slow internet connection. Please try again later')
            });
    }
    getVlgAlt() {
        fetch(config.api, {
                method: 'POST',
                headers: new Headers({
                    'Accept': 'application/json',
                    "Accept-Encoding": "gzip, deflate",
                    'Content-Type': 'application/json'
                }),
                body: JSON.stringify({
                    key: config.apiKey,
                    action: "get_villages_alt",
                })
            }).then(response => response.json())
            .then((e) => {
                store.dispatch(GetVillagesAlt(e));
                this.setState({
                    status: 'Fetching Consumers...', 
                }, () => this.fetchConsumers());
            })
            .catch((error) => {
                console.log(error);
                Alert.alert('Something went wrong', 'We are facing some technical difficulties at this moment, its maybe because of slow internet connection. Please try again later')
            });
    }
    fetchConsumers() {
        fetch(config.api, {
            method: 'POST',
            headers: new Headers({
                'Accept': 'application/json',
                "Accept-Encoding": "gzip, deflate",
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify({
                key: config.apiKey,
                action: "get_consumers",
            })
        }).then(response => response.json())
            .then((e) => {
                console.log(e);
                store.dispatch(SetConsumerDb(e));
                store.dispatch(SetStatus({ status: 'updated', timestamp: moment().format('MM-DD-YYYY,H:mm:ss') }))
                this.setState({
                    loader: false,
                    status: 'All Done.',
                }, () => this.goBack());
            })
            .catch((error) => {
                console.log(error);
                Alert.alert('Something went wrong', 'We are facing some technical difficulties at this moment, its maybe because of slow internet connection. Please try again later')
                this.setState({
                    loader: false
                })
            });
    }
    goBack() {
        ToastAndroid.show('All Done, Please continue!', ToastAndroid.LONG);
        this.props.navigation.goBack();
    }
    render() {
        return (
            <View style={{ flex: 1 }}>
                <Appbar.Header style={{ zIndex: 9 }}>
                    <Appbar.Content title="Welcome" />
                    <Appbar.Action icon="power" onPress={() => BackHandler.exitApp()} />
                </Appbar.Header>
                <View style={styles.base}>
                    <View style={{ flex: 1, justifyContent: 'center', alignSelf: 'center' }}>
                        <View style={styles.loader}>
                            {this.state.loader == true && <ActivityIndicator animating={true} />}
                            <Subheading style={{ marginTop: 20 }}>{this.state.status}</Subheading>
                        </View>
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    base: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
    },
    item: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center',
        textAlign: 'center'
    },
    img: {
        width: 150,
        height: 150,
        borderRadius: 100,
        resizeMode: 'contain'
    }
});