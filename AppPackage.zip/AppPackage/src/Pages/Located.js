import React, { Component } from "react";
import {View,ScrollView,TouchableOpacity,TextInput,Text,StyleSheet,Dimensions,ToastAndroid, Alert} from "react-native";
import { Appbar, Button, Subheading, Portal, Modal,ActivityIndicator, Headline, Title, Caption } from "react-native-paper";
import Icon from 'react-native-vector-icons/Feather';
// REDUX
import { store } from "../Redux/Store";
import config from '../Config/config';

export default class Located extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loader: true,
      data: [],
    };
  }
  componentDidMount(){
    fetch(config.api, {
            method: 'POST',
            headers: new Headers({
                'Accept': 'application/json',
                "Accept-Encoding": "gzip, deflate",
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify({
                key: config.apiKey,
                action: "get_mapped_villages",
            })
        }).then(response => response.json())
        .then((e) => {
            this.setState((prev) => ({
                loader: false,
                data: e,
            }));
        })
        .catch((error) => {
            console.log(error);
        });
  }
  
  render() {
    let data;
    console.log(this.state.data);
    if (Object.keys(this.state.data).length > 0) {
      data = Object.keys(this.state.data).map((e) => {
        var d = this.state.data[e];
        return(
          <View style={styles.row} key={e}>
            <Subheading>{d.village_name}</Subheading>
            <Caption>Village Code: {d.village_code}</Caption>
            <Caption>Zone: {d.zone}, Circle: {d.circle}</Caption>
            <Caption>Division: {d.division}, Sub Division: {d.subdivision}</Caption>
            <Button mode='contained' onPress={() => this.props.navigation.navigate('Map',{village:d})} style={{marginTop:10}}>Edit</Button>
          </View>
        )
      });
    } else {
      data = <View style={styles.row}>
              <Subheading>No data</Subheading>
            </View>
    }
    return (
      <View style={{ flex: 1 }}>
        <Appbar.Header style={{ zIndex: 9 }}>
          <Appbar.Action
            icon="keyboard-arrow-left"
            onPress={() => this.props.navigation.goBack()}
          />
          <Appbar.Content title="Located Villages" />
        </Appbar.Header>
        <ScrollView style={styles.main}>
          {data}
          <Text>&nbsp;</Text>
        </ScrollView>
        <Portal>
          <Modal visible={this.state.loader} onDismiss={()=>this.setState({loader:false})} style={{flex:1}}>
            <View style={{flex:1,justifyContent:'center',alignSelf: 'center'}}>
              <View style={styles.loader}>
              <ActivityIndicator animating={true} />
              <Subheading style={{marginTop:20}}>Please Wait..</Subheading>
            </View>
            </View>
          </Modal>
        </Portal>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  imageBg: {
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    position: "absolute"
  },
  imgBg: {
    flex: 1,
    width: "100%",
    height: "100%",
    resizeMode: "cover"
  },
  header: {
    height: "45%"
  },
  icon: {
    width: "35%",
    height: "35%",
    resizeMode: "contain",
    position: "absolute",
    top: 20
  },
  inputCon: {
    height: "55%"
  },
  imgBtmBg: {
    flex: 1,
    padding: 15,
    justifyContent: "center"
  },
  pickerCon: {
    borderRadius: 5,
    overflow: "hidden"
  },
  picker: {
    color: "#fff",
    paddingVertical: 30,
    backgroundColor: "#448aff"
  },
  btn: {
    color: "#fff",
    marginTop: 10,
    paddingVertical: 8,
    backgroundColor: "#ad4804"
  },
  main: {
    flex: 1,
    width: "100%",
    padding: 20,
    paddingTop: 10
  },
  input: {
    borderRadius: 5,
    marginBottom: 5,
    paddingVertical: 15,
    paddingHorizontal: 20,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#bdbdbd"
  },
  disInput: {
    backgroundColor: "#e0e0e0",
    color: '#000',
    fontWeight: 'bold'
  },
  searchCon: {
    flexDirection: 'row',
    position: 'relative',
    alignItems: 'center',
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#bdbdbd",
    borderRadius: 5,
    marginBottom: 5,
    overflow: 'hidden'
  },
  inputAlt: {
    flexGrow:1,
    paddingVertical: 15,
    paddingHorizontal: 20,
    backgroundColor: "#fff",
  },
  search: {
    fontSize:28,
    zIndex: 9,
    paddingHorizontal:10
  },
  loader: {
    padding: 20,
    paddingHorizontal: 40,
    backgroundColor: '#fff',
    justifyContent:'center',
    alignItems:'center',
    overflow: 'hidden',
    borderRadius: 5,
    height: 150,
  },
  row: {
    borderColor: '#e0e0e0',
    borderWidth: 1,
    borderRadius: 5,
    marginVertical: 5,
    padding: 10,
  }
});
