import React, { Component } from "react";
import {View,ScrollView,TextInput,Text,StyleSheet,Dimensions} from "react-native";
import { Appbar, Button, Subheading, Headline, Badge } from "react-native-paper";
import { store,persistor } from "../Redux/Store";
import RNRestart from 'react-native-restart';
import config from '../Config/config';

export default class HomeAlt extends Component {
    constructor(props) {
        super(props);
        this.state = {
            village: store.getState().village,
            villages: {
                located: 0,
                unlocated: 0,
            },
            consumers: {
                mapped: 0,
                unmapped: 0
            }
        }
    }
    componentDidMount() {
        store.subscribe(() => {
            this.setState({
                village: store.getState().village
            })
        })
        fetch(config.api, {
            method: 'POST',
            headers: new Headers({
                'Accept': 'application/json',
                "Accept-Encoding": "gzip, deflate",
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify({
                key: config.apiKey,
                action: "get_user_stat",
            })
        }).then(response => response.json())
        .then((e) => {
            villages = e.villages
            consumers = e.consumers
            this.setState((prev) => ({
                ...prev,
                villages,
                consumers
            }));
            console.log(this.state);
        })
        .catch((error) => {
            console.log(error);
        });
    }
    logout() {
        persistor.purge()
            .then(RNRestart.Restart())
    }
    render() {
        return(
            <View style={{flex:1}}>
                <Appbar.Header style={{ zIndex: 9 }}>
                    <Appbar.Action icon="chevron-left" onPress={() => this.props.navigation.goBack()} />
                    <Appbar.Content title="Consumer Survey" />
                    <Appbar.Action icon="exit-to-app" onPress={() => this.logout()} />
                </Appbar.Header>
                <View style={styles.main}>
                    <View style={styles.container}>
                        {/*<View style={{borderColor:'#2196f3',borderWidth:2,marginBottom:20}}>
                            <Headline style={{textAlign:'center',paddingVertical:10, borderColor:'#2196f3',borderBottomWidth:2}}>Villages</Headline>
                            <View style={styles.row}>
                                <Button
                                    style={styles.btn}
                                    mode="contained"
                                    onPress={() => this.props.navigation.navigate('Located')}
                                > 
                                    Located
                                </Button>
                                <Badge style={styles.badge}>{this.state.villages.located}</Badge>
                            </View>
                            <View style={[styles.row, { borderBottomWidth: 0 }]}>{
                                this.state.village.length == 0 ? <Button
                                    style={styles.btn}
                                    mode="contained"
                                    onPress={() => this.props.navigation.navigate('Villages')}
                                >
                                    Unlocated
                                </Button> : <Subheading>Unlocated:</Subheading>
                            }<Badge style={styles.badge}>{this.state.villages.unlocated}</Badge></View>
                            
                        </View>*/}
                        <View style={{borderColor:'#2196f3',borderWidth:2}}>
                            <Headline style={{textAlign:'center',paddingVertical:10, borderColor:'#2196f3',borderBottomWidth:2}}>Consumers</Headline>
                            <View style={styles.row}><Subheading>Mapped:</Subheading><Badge style={styles.badge}>{this.state.consumers.mapped}</Badge></View>
                            <View style={[styles.row, {borderBottomWidth:0}]}><Button
                                // style={styles.btn}
                                mode="contained"
                                onPress={() => {store.getState().villageAlt.length == 0 ? this.props.navigation.navigate('Villages2'):this.props.navigation.navigate('Consumer')}}
                            >
                                Unmapped
                                </Button><Badge style={styles.badge}>{this.state.consumers.unmapped}</Badge></View>
                        </View>
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    btn: {
        color: "#fff",
        backgroundColor: "#f44336"
    },
    main: {
        flex: 1,
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center'
    },
    container: {
        width: '100%',
        padding: 20,
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        borderColor: '#2196f3', 
        borderBottomWidth: 2,
        paddingHorizontal: 20,
        paddingVertical:10,
    },
    badge: {
        top:-3
    },
    childCOn: {
        paddingVertical: 20,
        
    }
});