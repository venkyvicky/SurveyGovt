import React, { Component } from 'react';
// REDUX
import { store } from  '../Redux/Store';

export default class authLoader extends Component {
    constructor(props) {
        super(props);
        store.getState().user.length == 0 ? this.props.navigation.navigate('Login') : this.props.navigation.navigate('App');
    }
    render() {
        return null;
    }
}