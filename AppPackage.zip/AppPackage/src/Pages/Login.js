import React, {Component} from 'react';
import {View, TextInput, Image, StyleSheet, Dimensions, Clipboard, Alert, ToastAndroid} from 'react-native';
import {TextInput as Input, Button, Headline, Text} from 'react-native-paper';
import Icon from 'react-native-vector-icons/Feather';
// REDUX
import {store} from '../Redux/Store';
import {HndlLogin} from '../Redux/Actions/Actions';
// CONFIG
import config from '../Config/config';
import md5 from 'md5';

export default class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username: '',
            password: '',
            button: 'login',
            color: '#FF8C00',
        }
    }
    componentDidMount(){
        
    }
    _login() {
        if (this.state.username != '' && this.state.password != ''){
            this.setState({
                button: 'Please Wait..',
                color: '#bdbdbd'
            });
            fetch(config.api, {
                method: 'POST',
                headers: new Headers({
                    'Accept': 'application/json',
                    "Accept-Encoding": "gzip, deflate",
                    'Content-Type': 'application/json'
                }),
                body: JSON.stringify({
                    key: config.apiKey,
                    action: "login",
                    user: this.state.username,
                    password:this.state.password,
                })
            }).then(response => response.json())
            .then((e) => {
                console.log(e);
                if (e.status == 'success') {
                    this.setState({
                        button: 'Login',
                        color: '#FF8C00'
                    });
                    store.dispatch(HndlLogin(e));
                    this.props.navigation.navigate('App');
                } else if (e.status == 'false') {
                    Alert.alert('Login failed', 'Please check your Username and Password');
                    this.setState({
                        button: 'Try Again',
                        color: '#f44336'
                    });
                } else {
                    ToastAndroid.show('Sorry, something went wrong. Contact Support', ToastAndroid.SHORT);
                    this.setState({
                        button: 'Try Again',
                        color: '#f44336'
                    });
                }
            }).catch((error) => {
                console.error(error);
                ToastAndroid.show('Sorry, something went wrong. Contact Support', ToastAndroid.SHORT);
                this.setState({
                    button: 'Try Again',
                    color: '#f44336'
                });
            });
        } else {
            this.setState({
                button: 'Try Again',
                color: '#f44336'
            });
            ToastAndroid.show('Please enter both Username and Password', ToastAndroid.SHORT);
        }
    }
    render() {
        return(
            <View style={{flex:1}}>
                <View style={styles.header}>
                    <Image style={styles.img} source={require('../Images/technician.png')} />
                    <Headline style={styles.title}>Consumer Survey</Headline>
                </View>
                <View style={styles.login}>
                    <View style={{marginTop:60}}>
                        <View style={styles.inputWrapper}>
                            <Icon name='user' size={30} color='#616161' />
                            <TextInput
                                style={styles.input}
                                value={this.state.username}
                                placeholder='Enter your Username'
                                onChangeText={(e) => this.setState({username:e})}
                            />
                        </View>
                        <View style={styles.inputWrapper}>
                            <Icon name='lock' size={30} color='#616161' />
                            <TextInput
                                style={styles.input}
                                value= {this.state.password}
                                placeholder='Enter your Password'
                                secureTextEntry={true}
                                onChangeText={(e) => this.setState({password:e})}
                            />
                        </View>
                        <Button mode='contained' style={[styles.btn, {backgroundColor:this.state.color}]} contentStyle={{height:50}} onPress={() => this._login()}>
                            {this.state.button}
                        </Button>
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    header: {
        height: '40%',
        backgroundColor: '#FF8C00',
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center',
    },
    login: {
        height: '60%',
        paddingHorizontal: 30,
    },
    img: {
        width: '55%',
        height: '55%',
        resizeMode: 'contain'
    },
    title: {
        color: '#000',
        marginTop: 15,
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10
    },
    input: {
        marginLeft:20,
        borderWidth: 1,
        borderRadius: 5,
        paddingHorizontal: 20,
        width: Dimensions.get('screen').width - 110,
        borderColor: '#616161',
    },
    btn: {
        marginTop: 15,
        width: Dimensions.get('screen').width - 60,
    }
});