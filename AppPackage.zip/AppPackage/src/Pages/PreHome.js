import React, { Component } from "react";
import {View,ScrollView,Image,TextInput,Text,StyleSheet,Dimensions, TouchableOpacity,Alert} from "react-native";
import { Appbar, Button, Subheading, Headline, Badge } from "react-native-paper";
import Icon from 'react-native-vector-icons/Feather';
import { store,persistor } from "../Redux/Store";
import RNRestart from 'react-native-restart';
import config from '../Config/config';

export default class PreHome extends Component {
    constructor(){
        super();
        this.state = {

        }
    }
    componentDidMount() {
        if (store.getState().installationStatus == 'new'){
            this.props.navigation.navigate('PreFlight');
        }
    }
    
    
    logout() {
        persistor.purge()
            .then(RNRestart.Restart())
    }
    render() {
        return (
            <View style={{flex:1}}>
                <Appbar.Header style={{zIndex:9}}>
                    <Appbar.Content title="Consumer Survey"/>
                    <TouchableOpacity onPress={() => this.props.navigation.navigate('PushUpdate')}>
                        <Icon name="save" size={25} color='#000'  />
                        {store.getState().villagePushed === true && <Badge style={{ position: 'absolute', bottom: -4, left: -8 }}>1</Badge>}
                        {store.getState().consumerToPush.length !== 0 && <Badge style={{position:'absolute',bottom:-4,left:-8}}>{store.getState().consumerToPush.length}</Badge>}
                    </TouchableOpacity>
                    <Appbar.Action icon="exit-to-app" onPress={() => this.logout()} />
                </Appbar.Header>
                <View style={styles.base}>
                    <TouchableOpacity style={StyleSheet.item} onPress={() => this.props.navigation.navigate('Home')}>
                        <Image source={require('../Images/village.png')} style={styles.img} />
                        <Headline style={{textAlign:'center',marginTop:10}}>Map Villages</Headline>
                    </TouchableOpacity>
                    <TouchableOpacity style={StyleSheet.item} onPress={() => this.props.navigation.navigate('HomeAlt')}>
                        <Image source={require('../Images/group.png')} style={styles.img} />
                        <Headline style={{textAlign:'center',marginTop:10}}>Map Consumers</Headline>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    base: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
    },
    item: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center',
        textAlign: 'center'
    },
    img: {
        width: 150,
        height: 150,
        borderRadius: 100,
        resizeMode: 'contain'
    }
});