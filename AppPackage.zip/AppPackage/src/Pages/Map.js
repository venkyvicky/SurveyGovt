import React, {Component} from 'react';
import {View, ScrollView, TextInput, ImageBackground, Image, Picker, StyleSheet, Dimensions, PermissionsAndroid} from 'react-native';
import { Appbar, Button, Subheading, Caption } from 'react-native-paper';
import MapView, { PROVIDER_GOOGLE, Marker } from 'react-native-maps';
import Geolocation from 'react-native-geolocation-service';
import RNGooglePlaces from 'react-native-google-places';
// REDUX
import {store} from '../Redux/Store';

export default class Map extends Component {
    constructor(props) {
        super(props);
        this.state = {
            geo: {
                coords: {
                    latitude: 27.0784601,
                    longitude: 79.5763141,
                }
            },
            location: '72/B Mukundapur, Kolkata, West Bengal, India',
            village: this.props.navigation.getParam('village'),
        }
    }
    async componentDidMount() {
         await this.requestLocationPermission();
         Geolocation.getCurrentPosition(
                (position) => {
                    console.log(position);
                    this.setState({geo:position})
                },(error) => {
                    // See error code charts below.
                    console.log(error.code, error.message);
                },{ enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
            );
    }
    async requestLocationPermission() {
        try {
            const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION, {
                    'title': 'Allow Location Permission',
                    'message': 'We need access to your location for further proccess'
                });

            if (granted === PermissionsAndroid.RESULTS.GRANTED) {

            } else {
                console.log("location permission denied")
                alert("Please Allow Location Access");
                granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION, {
                    'title': 'Allow Location Permission',
                    'message': 'We need access to your location for further proccess'
                });
            }
        } catch (err) {
            console.warn(err)
        }
    }
    _submitLocation() {
        this.props.navigation.navigate('Location', {village:this.state.village,location:this.state.geo.coords});
    }
    _setMarker(e){
        console.log(e);
        this.setState((prev) => ({
            geo: {
                ...prev.geo,
                coords: {
                    ...prev.geo.coords,
                    latitude: e.coordinate.latitude,
                    longitude: e.coordinate.longitude
                }
            }
        }))
    }
    openSearchModal() {
    RNGooglePlaces.openAutocompleteModal()
        .then((place) => {
            console.log(place);
            // place represents user's selection from the
            // suggestions and it is a simplified Google Place object.
            this.setState((prev) => ({
                geo: {
                    ...prev.geo,
                    coords: {
                        ...prev.geo.coords,
                        latitude: place.location.latitude,
                        longitude: place.location.longitude
                    }
                }
            }))
        })
        .catch(error => console.log(error.message));  // error is a Javascript Error object
    }
    render(){
        return(
            <View style={{flex:1}}>
                <Appbar.Header style={{zIndex:9}}>
                    <Appbar.Action icon="chevron-left" onPress={() => this.props.navigation.goBack()} />
                    <Appbar.Content title="Location"/>
                </Appbar.Header>
                <ScrollView style={styles.main}>
                    
                <Subheading style={{color:'#757575',marginBottom:5}}>Mark location:</Subheading>
                    <View style={styles.mapCon}>
                        <Image source={require('../Images/location.png')} style={styles.marker} />
                        <MapView
                            provider={PROVIDER_GOOGLE} // remove if not using Google Maps
                            style={styles.map}
                            region={{
                                latitude: this.state.geo.coords.latitude,
                                longitude: this.state.geo.coords.longitude,
                                latitudeDelta: 0.01,
                                longitudeDelta: 0.01,
                            }}
                            // onPress={(e)=> this._setMarker(e.nativeEvent)}
                            showsUserLocation={true}
                            showsMyLocationButton={true}
                            followsUserLocation={true}
                            loadingEnabled={true}
                            onRegionChangeComplete = {
                                (e) => this._setMarker({
                                    coordinate: {
                                        latitude: e.latitude,
                                        longitude: e.longitude,
                                    }
                                })
                            }
                        >
                            
                        </MapView>
                    </View>
                    <Subheading style={{color:'#757575',marginBottom:5,marginTop:20}}>Location Details:</Subheading>
                    <Caption>
                        Village: {this.state.village.village_name}{'\n'}
                        Division: {this.state.village.division}{'\n'}
                        Sub Division: {this.state.village.subdivision}{'\n'}
                        Latitude: {this.state.geo.coords.latitude}{"\n"}
                        Longitude: {this.state.geo.coords.longitude}{'\n'}
                        
                    </Caption>
                    <Button style={styles.btn} contentStyle={{height:50}} mode='contained' onPress={()=> this._submitLocation()}>
                        Next
                    </Button>
                    <Subheading>&nbsp;</Subheading>
                </ScrollView>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    imageBg: {
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        position: 'absolute',
    },
    imgBg: {
        flex:1,
        width: '100%',
        height: '100%',
        resizeMode: 'cover'
    },
    header: {
        height: '45%',
    },
    icon: {
        width: '35%',
        height: '35%',
        resizeMode: 'contain',
        position: 'absolute',
        top: 20,
    },
    inputCon: {
        height: '55%'
    },
    imgBtmBg: {
        flex: 1, 
        padding: 15,
        justifyContent: 'center',
    },
    pickerCon: {
        borderRadius: 5,
        overflow: 'hidden',
    },
    picker: {
        color: '#fff',
        paddingVertical:30,
        backgroundColor: '#448aff',
    },
    btn: {
        color: '#fff',
        backgroundColor: '#FF8C00',
    },
    main: {
        flex:1,
        padding: 20,
        width: '100%',
        height: '100%',
        paddingTop: 10,
    },
    mapCon: {
        height: 300,
        borderRadius: 5,
        marginBottom: 10,
        overflow: 'hidden',
        borderColor: '#bdbdbd',
        borderWidth: 1,
    },  
    map: {
        resizeMode: 'cover'
    },
    input: {
        borderRadius: 5,
        paddingVertical: 15,
        paddingHorizontal: 20,
        backgroundColor: '#fff',
        textAlignVertical: 'top',
        borderWidth: 1,
        borderColor: '#bdbdbd'
    },
    container: {
        ...StyleSheet.absoluteFillObject,
        height: 400,
        width: 400,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    map: {
        ...StyleSheet.absoluteFillObject,
    },
    marker: {
        position: 'absolute',
        left: (Dimensions.get('window').width / 2) - 45,
        top: (350 / 2) - 45,
        zIndex: 99,
        width: 45,
        height: 45,
        resizeMode: 'contain'
    }
});