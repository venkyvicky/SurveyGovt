import React, { Component } from "react";
import {View,ScrollView,Image,TextInput,Text,StyleSheet,Dimensions, TouchableOpacity,Alert} from "react-native";
import { Appbar, Button, Subheading, Headline, Badge, Portal, Modal, ActivityIndicator, } from "react-native-paper";
import Icon from 'react-native-vector-icons/Feather';
import { store,persistor } from "../Redux/Store";
import config from '../Config/config';
import {SetVillagePush,ClearConsumerPush} from '../Redux/Actions/Actions';
import {connect} from '../Redux/Actions/Connect.js';

export default class PushUpdate extends Component {
    constructor(){
        super();
        this.state = {
            loader: false,
        }
    }
    componentDidMount() {
        connect();
    }
    uploadVillageData() {
        this.setState({
            loader: true,
        });
        fetch(config.api, {
            method: 'POST',
            headers: new Headers({
                'Accept': 'application/json',
                "Accept-Encoding": "gzip, deflate",
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify({
                key: config.apiKey,
                action: "update_village",
                village: store.getState().village.village,
                location: store.getState().village.location,
                image: store.getState().village.image,
            })
        }).then(response => response.json())
            .then((e) => {
                console.log(e);
                if (e.status == 'success') {
                    this.setState({
                        loader: false,
                    });
                    store.dispatch(SetVillagePush(false));
                    Alert.alert('Success', 'Pending Data has been updated to server successfully');
                    this.forceUpdate();
                } else {
                    ToastAndroid.show('Sorry, something went wrong. Contact Support', ToastAndroid.SHORT);
                    this.setState({
                        loader: false,
                    });
                }
            }).catch((error) => {
                console.error(error);
                ToastAndroid.show('Sorry, something went wrong. Contact Support', ToastAndroid.SHORT);
                this.setState({
                    loader: false,
                });
            });
    }
    uploadConsumerData() {
        this.setState({
            loader: true,
        });
        store.getState().consumerToPush.map((consumer, i) => {
            // console.log(consumer);
            fetch(config.api, {
                method: 'POST',
                headers: new Headers({
                    'Accept': 'application/json',
                    "Accept-Encoding": "gzip, deflate",
                    'Content-Type': 'application/json'
                }),
                body: JSON.stringify({
                    key: config.apiKey,
                    action: "update_consumer",
                    mobile: consumer.mobile,
                    consumer: consumer.consumer,
                    village: consumer.village,
                    mstatus: consumer.mstatus,
                    edit: consumer.edit,
                    latitude: consumer.latitude,
                    longitude: consumer.longitude,
                    location: consumer.location,
                    // images & docs
                    doc_aadhar: consumer.doc_aadhaar,
                    doc_aadhar_qr: consumer.doc_aadhar_qr,
                    doc_meter: consumer.doc_meter,
                    user: store.getState().user.username,
                    raw_location: consumer.raw_location,
                })
            }).then(response => response.json())
                .then((e) => {
                    if (e.status == 'success') {
                        store.dispatch(ClearConsumerPush(null));
                        Alert.alert('Success', 'Pending Data has been updated to server successfully');
                        this.forceUpdate();
                    } else {
                        ToastAndroid.show('Unknown error, Please contact support', ToastAndroid.SHORT);
                    }
                    this.setState({
                        loader: false,
                    })
                })
                .catch((error) => {
                    console.log(error);
                    ToastAndroid.show('Unknown error, Please contact support', ToastAndroid.SHORT);
                    this.setState({
                        loader: false,
                    })
                });
        })
    }
    render() {
        let consumers = store.getState().consumerToPush.map((consumer, i) => {
            return (
                <View key={i} style={styles.consumer}>
                    <Text style={{ fontWeight: 'bold' }} >Consumer No: {consumer.consumer.consumer_code}</Text>
                    <Text>Name: {consumer.consumer.consumer_name}</Text>
                </View>
            );
        })
        return (
            <View style={{flex:1}}>
                <Appbar.Header style={{zIndex:9}}>
                    <Appbar.Action icon="chevron-left" onPress={() => this.props.navigation.goBack()} />
                    <Appbar.Content title="Push Update"/>
                </Appbar.Header>
                <View style={styles.base}>
                    {store.getState().villagePushed === true &&
                        <View style={styles.container}>
                            <View style={{flexGrow:1}}>
                                <Subheading style={{fontWeight:'bold'}}>Update Pending</Subheading>
                                <Text>Village data update pending</Text>
                            </View>
                            <TouchableOpacity style={{justifyContent:'center',alignItems:'center'}} onPress={() => this.uploadVillageData()}>
                                <Icon name='upload-cloud' size={30} />
                                <Text>Upload</Text>
                            </TouchableOpacity>
                        </View>
                    }
                    {store.getState().consumerToPush.length !== 0 &&
                        <ScrollView style={styles.containerView}>
                            <View style={{flexDirection:'row',alignItems:'center',borderColor: '#e0e0e0',borderBottomWidth:1,margin:20,marginBottom:0,paddingBottom:20}}>
                                <View style={{ flexGrow: 1 }}>
                                    <View style={{flexDirection:'row'}}>
                                        <Subheading style={{ fontWeight: 'bold' }}>Update Pending</Subheading>
                                        <Badge style={{marginLeft:10,top:-3}}>{store.getState().consumerToPush.length}</Badge>
                                    </View>
                                    <Text>Consumer data update pending</Text>
                                </View>
                                <TouchableOpacity style={{ justifyContent: 'center', alignItems: 'center' }} onPress={() => this.uploadConsumerData()}>
                                    <Icon name='upload-cloud' size={30} />
                                    <Text>Upload</Text>
                                </TouchableOpacity>
                            </View>
                            {consumers}
                        </ScrollView>
                    }
                </View>
                <Portal>
                    <Modal visible={this.state.loader} onDismiss={() => this.setState({ loader: false })} style={{ flex: 1 }}>
                        <View style={{ flex: 1, justifyContent: 'center', alignSelf: 'center' }}>
                            <View style={styles.loader}>
                                <ActivityIndicator animating={true} />
                                <Subheading style={{ marginTop: 20 }}>Please Wait..</Subheading>
                            </View>
                        </View>
                    </Modal>
                </Portal>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    base: {
        flex: 1,
        padding: 20,
    },
    item: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center',
        textAlign: 'center'
    },
    img: {
        width: 150,
        height: 150,
        borderRadius: 100,
        resizeMode: 'contain'
    },
    container: {
        backgroundColor: '#fff',
        borderRadius: 5,
        borderColor: '#e0e0e0',
        borderWidth: 1,
        padding:20,
        flexDirection: 'row',
        alignItems: 'center'
    },
    containerView: {
        borderWidth: 1,
        borderColor: '#e0e0e0',
        marginTop: 10,
        borderRadius: 5
    },
    consumer: {
        borderBottomWidth: 1, 
        borderColor: '#e0e0e0',
        marginHorizontal: 20,
        paddingVertical: 20,
    },
    loader: {
        padding: 20,
        paddingHorizontal: 40,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
        borderRadius: 5,
        height: 150,
    },
});