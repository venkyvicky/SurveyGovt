import React, { Component } from "react";
import {View,ScrollView,Image,TouchableOpacity,TextInput,Text,StyleSheet,Dimensions,ToastAndroid, Alert, Picker, PermissionsAndroid} from "react-native";
import { Appbar, Button, Subheading, Portal, Modal,ActivityIndicator, Caption } from "react-native-paper";
import Icon from 'react-native-vector-icons/Feather';
import { RNCamera } from 'react-native-camera';
import MapView, { PROVIDER_GOOGLE, Marker } from 'react-native-maps';
import Geolocation from 'react-native-geolocation-service';
// REDUX
import {store} from '../Redux/Store';
import config from '../Config/config';

export default class Documents extends Component {
    constructor(props) {
        super(props);
        this.state = {
            phone: this.props.navigation.getParam('consumer').consumer_mobile,
            village: this.props.navigation.getParam('village'),
            consumer: this.props.navigation.getParam('consumer'),
            edit: this.props.navigation.getParam('edit'),
            // IMAGES
            modal: false,
            loader: false,
            imageMode: 'qr',
            aadhaar: null,
            aadhaar_qr: null,
            meter: null,
            mstatus: "Working",
            latitude: null,
            longitude: null,
            location: null,
        }
    }
    async componentDidMount() {
         await this.requestLocationPermission();
         Geolocation.getCurrentPosition(
                (position) => {
                    
                    
                    this.setState({
                        latitude: position.coords.latitude.toString(),
                        longitude: position.coords.longitude.toString(),
                    })
                    console.log(this.state);
                    this._getAddress(position.coords.latitude, position.coords.longitude);
                },(error) => {
                    // See error code charts below.
                    console.log(error.code, error.message);
                },{ enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
            );
    }
    _submitConsumer() {
        console.log(this.state);
        if (this.state.meter != null ){
            this.props.navigation.navigate('Finish', {
                mobile: this.state.phone,
                consumer: this.state.consumer,
                village: this.state.village,
                mstatus: this.state.mstatus,
                edit: this.state.edit,
                // images & docs
                doc_aadhar: this.state.aadhaar,
                doc_aadhar_qr: this.state.aadhaar_qr,
                doc_meter: this.state.meter,
                location: {
                    latitude: this.state.latitude,
                    longitude: this.state.longitude,
                    address: this.state.location,
                }
            })
        } else {
            Alert.alert('Please Provide all the required info!');
        }
    }
    _getAddress(lat, long) {

        fetch("https://maps.googleapis.com/maps/api/geocode/json?latlng=" + lat + "," + long + "&key=" + config.googleApiKey, {
                method: 'POST',
                headers: new Headers({
                    'Accept': 'application/json',
                    "Accept-Encoding": "gzip, deflate",
                    'Content-Type': 'application/json'
                })
            }).then(response => response.json())
            .then((e) => {
                console.log(e);
                this.setState({
                    location: e.results[0].formatted_address,
                    inprogress: false,
                });
            })
            .catch((err) => {
                console.log(err);
                this.setState({
                    inprogress: false,
                });
            });
        this.setState({
            inprogress: true,
        });
    }
    async requestLocationPermission() {
        try {
            const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION, {
                'title': 'Allow Location Permission',
                'message': 'We need access to your location for further proccess'
            });

            if (granted === PermissionsAndroid.RESULTS.GRANTED) {

            } else {
                console.log("location permission denied")
                alert("Please Allow Location Access");
                granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION, {
                    'title': 'Allow Location Permission',
                    'message': 'We need access to your location for further proccess'
                });
            }
        } catch (err) {
            console.warn(err)
        }
    }
    _setMarker(e) {
        console.log(e);
        this._getAddress(e.coordinate.latitude, e.coordinate.longitude);
        this.setState((prev) => ({
            latitude: e.coordinate.latitude,
            longitude: e.coordinate.longitude,
        }))
    }
    takePicture = async(mode) => {
        if (this.camera) {
            const options = { quality: 0.5, base64: true };
            const data = await this.camera.takePictureAsync(options);

            
            if (this.state.imageMode == 'qr'){
                this.setState({
                    aadhaar_qr: "data:image/jpg;base64," + data.base64,
                    modal: false,
                });
            } else if (this.state.imageMode == 'aadhaar') {
                this.setState({
                    aadhaar: "data:image/jpg;base64," + data.base64,
                    modal: false,
                });
            } else if (this.state.imageMode == 'meter') {
                this.setState({
                    meter: "data:image/jpg;base64," + data.base64,
                    modal: false,
                });
            }
        }
    };
    _setQr(e){
        if (e.type == "QR_CODE"){
            if (e.data.includes('uid') && e.data.includes('name')) {
                this.setState({
                    aadhaar_qr:e.data,
                    modal: false,
                });
                ToastAndroid.show('Aadhar QR Scan success!', ToastAndroid.SHORT);
                console.log(e);
            }
        }
        
    }
    render(){
        return(
            <View style={{flex:1}}>
                <Appbar.Header style={{zIndex:9}}>
                    <Appbar.Action icon="chevron-left" onPress={() => this.props.navigation.goBack()} />
                    <Appbar.Content title="Consumer Documents"/>
                </Appbar.Header>
                <ScrollView style={styles.main}>
                    <Subheading style={{color:'#757575',marginBottom:5}}>Consumer's phone no:</Subheading>
                    <TextInput
                        style={styles.input}
                        value={this.state.phone}
                        keyboardType='numeric'
                        placeholder='Phone Number'
                        maxLength={10}
                        onChangeText={(e) => this.setState({phone:e})}
                    />
                    <Subheading style={{color:'#757575',marginBottom:5,marginTop:15}}>Aadhar's QR code data:</Subheading>
                    <View style={[styles.imgCon, {minHeight:150}]}>
                        <Caption>RAW XML: {this.state.aadhaar_qr}</Caption>
                    </View>
                    <Button style={styles.btnAlt} mode='contained' onPress={()=> this.setState({modal:true,imageMode:'qr'})}>
                        Open Scanner
                    </Button>
                    <Subheading style={{color:'#757575',marginBottom:5,marginTop:15}}>Capture Aadhar's picture:</Subheading>
                    <View style={styles.imgCon}>
                        <Image style={styles.img} source={{uri:this.state.aadhaar}} />
                    </View>
                    <Button style={styles.btnAlt} mode='contained' onPress={()=> this.setState({modal:true,imageMode:'aadhaar'})}>
                        Open Camera
                    </Button>
                    <Subheading style={{color:'#757575',marginBottom:5,marginTop:15}}>Capture Meter's picture *:</Subheading>
                    <View style={styles.imgCon}>
                        <Image style={styles.img} source={{uri:this.state.meter}} />
                    </View>
                    <Button style={styles.btnAlt} mode='contained' onPress={()=> this.setState({modal:true,imageMode:'meter'})}>
                        Open Camera
                    </Button>
                    <Subheading style={{ color: '#757575', marginBottom: 5,marginTop:20 }}>Latitude:</Subheading>
                    <TextInput
                        style={[styles.input, styles.disInput]}
                        value={this.state.latitude}
                        placeholder='latitude'
                        editable={false}
                    />
                    <Subheading style={{ color: '#757575', marginBottom: 5 }}>Longitude:</Subheading>
                    <TextInput
                        style={[styles.input, styles.disInput]}
                        value={this.state.longitude}
                        placeholder='Longitude'
                        editable={false}
                    />
                    <Subheading style={{ color: '#757575', marginBottom: 5 }}>Address:</Subheading>
                    <TextInput
                        style={[styles.input, styles.disInput]}
                        multiline={true}
                        numberOfLines={4}
                        value={this.state.location}
                        placeholder='Address'
                        editable={false}
                    />
                    
                    <Subheading style={{color:'#757575',marginBottom:5,marginTop:15}}>Meter Status:</Subheading>
                    <View style={{backgroundColor: '#fff',borderWidth: 1,borderColor: '#bdbdbd',borderRadius:5,padding:5,paddingLeft:10}}>
                        <Picker
                            selectedValue={this.state.mstatus}
                            onValueChange={(itemValue, itemIndex) =>
                                this.setState({mstatus: itemValue})
                            }>
                            <Picker.Item label="IDF: Informed defective/Meter defective/Damaged meter" value="IDF: Informed defective/Meter defective/Damaged meter" />
                            <Picker.Item label="ADF: Appears defective" value="ADF: Appears defective" />
                            <Picker.Item label="RDF: Reported defective" value="RDF: Reported defective" />
                            <Picker.Item label="NA/NR: No Access/No reading/Premises locked" value="NA/NR: No Access/No reading/Premises locked" />
                            <Picker.Item label="DO: Dial Over" value="DO: Dial Over" />
                            <Picker.Item label="SB: Seal Broken" value="SB: Seal Broken" />
                            <Picker.Item label="IR: Illegal Reconnection" value="IR: Illegal Reconnection" />
                            <Picker.Item label="TD: Temporary Disconnection" value="TD: Temporary Disconnection" />
                            <Picker.Item label="GB: Glass Broken" value="GB: Glass Broken" />
                            <Picker.Item label="MC: Meter Change" value="MC: Meter Change" />
                            <Picker.Item label="MR: Meter Removed (P.D.Connection)" value="MR: Meter Removed (P.D.Connection)" />
                        </Picker>
                    </View>
                    
                    
                    <Button style={styles.btn} mode='contained' onPress={()=> this._submitConsumer()}>
                        Next
                    </Button>
                    <Text style={{marginTop:20}}>&nbsp;</Text>
                </ScrollView>
                <Portal>
                    <Modal visible={this.state.loader} onDismiss={()=>this.setState({loader:false})} style={{flex:1}}>
                        <View style={{flex:1,justifyContent:'center',alignSelf: 'center'}}>
                        <View style={styles.loader}>
                        <ActivityIndicator animating={true} />
                        <Subheading style={{marginTop:20}}>Please Wait..</Subheading>
                        </View>
                        </View>
                    </Modal>
                </Portal>
                <Portal>
                    <Modal visible={this.state.modal} onDismiss={()=>this.setState({modal:false})} style={{flex:1}}>
                        <View style={styles.modalCon}>
                            <TouchableOpacity style={styles.close} onPress={() => this.setState({ modal:false })}>
                                <Icon name='x-circle' color='#fff' size={25} />
                            </TouchableOpacity>
                            {this.state.imageMode == 'qr'?<Image source={require('../Images/qr.png')} style={styles.qrOverlay}/>:null}
                                <RNCamera
                                    ref={ref => {this.camera = ref}}
                                    style={styles.preview}
                                    type={RNCamera.Constants.Type.back}
                                    flashMode={RNCamera.Constants.FlashMode.off}
                                    onBarCodeRead={(e)=> this.state.imageMode == 'qr' ? this._setQr(e):null}
                                    androidCameraPermissionOptions={{
                                        title: 'Permission to use camera',
                                        message: 'We need your permission to use your camera',
                                        buttonPositive: 'Ok',
                                        buttonNegative: 'Cancel',
                                    }}
                                    androidRecordAudioPermissionOptions={{
                                        title: 'Permission to use audio recording',
                                        message: 'We need your permission to use your audio',
                                        buttonPositive: 'Ok',
                                        buttonNegative: 'Cancel',
                                    }}
                                />
                            <TouchableOpacity onPress={() => this.state.imageMode == 'qr'?null:this.takePicture()} style={styles.capture}>
                                <Text style={{ fontSize:15,color: '#fff' }}>{this.state.imageMode == 'qr'? "Scan Aadhar's QR": this.state.imageMode == 'aadhaar'?"Capture Aadhar's Image":"Capture Meter Image"}</Text>
                            </TouchableOpacity>
                        </View>
                    </Modal>
                </Portal>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    imageBg: {
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        position: 'absolute',
    },
    imgBg: {
        flex:1,
        width: '100%',
        height: '100%',
        resizeMode: 'cover'
    },
    header: {
        height: '45%',
    },
    icon: {
        width: '35%',
        height: '35%',
        resizeMode: 'contain',
        position: 'absolute',
        top: 20,
    },
    inputCon: {
        height: '55%'
    },
    imgBtmBg: {
        flex: 1, 
        padding: 15,
        justifyContent: 'center',
    },
    pickerCon: {
        borderRadius: 5,
        overflow: 'hidden',
    },
    picker: {
        color: '#fff',
        paddingVertical:30,
        backgroundColor: '#448aff',
    },
    btn: {
        color: '#fff',
        marginTop: 25,
        paddingVertical: 8,
        backgroundColor: '#FF8C00',
    },
    btnAlt: {
        marginTop: 5,
        paddingVertical: 5,
    },
    main: {
        flex:1,
        padding: 20,
        width: '100%',
        height: '100%',
        paddingBottom: 10,
        
    },
    input: {
        borderRadius: 5,
        paddingVertical: 15,
        paddingHorizontal: 20,
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#bdbdbd'
    },
    disInput: {
        backgroundColor: '#e0e0e0',
        color: '#212121',
    },
    imgCon: {
        overflow: 'hidden',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#bdbdbd'
    },
    img: {
        width: '100%',
        height: 200,
        resizeMode: 'cover',
    },
    loader: {
        padding: 20,
        paddingHorizontal: 40,
        backgroundColor: '#fff',
        justifyContent:'center',
        alignItems:'center',
        overflow: 'hidden',
        borderRadius: 5,
        height: 150,
    },
    // MODAL
    preview: {
        width: '100%',
        height: 50,
        resizeMode: 'contain'
    },
    capture: {
        height: 55,
        color: '#ffffff',
        alignContent: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FF8C00',
    },
    close: {
       position: 'absolute',
       margin: 10,
       zIndex: 99,
       right: 0,
    },
    modalCon: {
        flexDirection: 'column',
        backgroundColor: '#fff',
        overflow: 'hidden',
        width: '100%',
        height: '100%'
    },
    preview: {
        flex:1,
        height: '100%',
        width: '100%',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    qrOverlaycon: {

    },
    qrOverlay: {
        position: 'absolute',
        zIndex: 999,
        resizeMode: 'contain',
        width: '70%',
        marginLeft: '15%'
    },
    mapCon: {
        height: 250,
        marginTop: 15,
        width: '100%',
        borderRadius: 5,
        marginBottom: 10,
        overflow: 'hidden',
        borderColor: '#bdbdbd',
        borderWidth: 1,
    },  
    map: {
        //resizeMode: 'cover'
        ...StyleSheet.absoluteFillObject,
        flex: 1
    },
});