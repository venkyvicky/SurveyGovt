import {createStackNavigator} from 'react-navigation-stack';
// PAGES
import Home from './Home';
import PreHome from './PreHome';
import HomeAlt from './HomeAlt';
import Map from './Map';
import Villages from './Villages';
import Location from './Location';
import Consumer from './Consumer';
import Documents from './Documents';
import Map2 from './Map2';
import Villages2 from './Villages2';
import Finish from './Finish';
import Located from './Located';
import PreFlight from './PreFlight';
import PushUpdate from './PushUpdate';

export default MainApp = createStackNavigator({
    PreHome: {screen: PreHome},
    Home: {screen: Home},
    HomeAlt: {screen: HomeAlt},
    Map: {screen: Map},
    Villages:{screen: Villages},
    Map2: {screen: Map2},
    Villages2:{screen: Villages2},
    Location: {screen: Location},
    Consumer: {screen: Consumer},
    Documents: {screen: Documents},
    Finish: { screen: Finish },
    Located: {screen: Located},
    PreFlight: {screen: PreFlight},
    PushUpdate: {screen: PushUpdate}
 },{
    initialRouteName: "PreHome",
    headerMode: 'none'
});