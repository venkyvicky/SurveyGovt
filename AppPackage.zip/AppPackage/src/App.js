import React, {Component} from 'react';
import {DefaultTheme,Provider as PaperProvider,Text} from 'react-native-paper';
import {createSwitchNavigator, createAppContainer} from 'react-navigation';
// SPLASHSCREEN
// import SplashScreen from 'react-native-splash-screen';
// MAIN APP
// import MainApp from './Pages/MainApp';
// REDUX
import {persistor, store} from './Redux/Store';
import {Provider as StoreProvider} from 'react-redux';
import {PersistGate} from 'redux-persist/integration/react';
// PAGES
import Login from './Pages/Login';
import authLoader from './Pages/AuthLoader';
import MainApp from './Pages/MainApp';
import { timer_destroy } from './Redux/Actions/Connect';
// Disable yellowbox
console.disableYellowBox = true;

const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#FF8C00',
    //accent: 'yellow',
  },
};

const Switch = createSwitchNavigator({
    Login: { screen: Login },
    Load: { screen: authLoader },
    App: { screen: MainApp },
  },{
    initialRouteName: 'Load',
    headerMode: 'none',
});
export const RootView = createAppContainer(Switch);

export default class App extends Component {
  componentDidMount() {
    // timer_destroy();
  }
  render() {
    return (
      <StoreProvider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <PaperProvider theme={theme}>
            <RootView />
          </PaperProvider>
        </PersistGate>
      </StoreProvider>
    );
  }
}
